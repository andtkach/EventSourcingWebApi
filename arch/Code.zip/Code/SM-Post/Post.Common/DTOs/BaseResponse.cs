namespace Post.Common.DTOs
{
    public class BaseResponse
    {
        public string Message { get; set; }
    }
}