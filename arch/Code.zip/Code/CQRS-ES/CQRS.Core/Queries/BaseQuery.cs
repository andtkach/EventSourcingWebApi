namespace CQRS.Core.Queries
{
    public abstract class BaseQuery
    {

    }
}