namespace CQRS.Core.Exceptions
{
    public class ConcurrencyException : Exception
    {

    }
}